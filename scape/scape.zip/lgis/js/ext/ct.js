define([ "dojo/_base/declare"], function (declare) {
    return declare("plot.ct", null, {
        constructor: function () {
            console.log("plot.ct");
        }
    });
}) ;
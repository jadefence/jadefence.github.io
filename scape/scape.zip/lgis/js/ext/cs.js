/**
 * Created by chenzpa on 2015/10/30.
 */
define([ "dojo/_base/declare"], function (declare) {
    return declare("plot.cs", null, {
        constructor: function () {
            console.log("plot.cs");
        },
        ga: function () {
            return null;
        }
    });
}) ;